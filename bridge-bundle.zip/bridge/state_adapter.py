from __future__ import annotations
import hashlib
from datetime import datetime, timezone
from typing import Any
from .protocol import SystemState

def _normalize_state(state: Any) -> str:
    if state is None:
        return ""
    if isinstance(state, str):
        return state
    if isinstance(state, (list, tuple)):
        return "".join(map(str, state))
    return str(state)

def build_state(fixer: Any, backup_hash: str | None = None) -> SystemState:
    code = _normalize_state(getattr(fixer, "state", ""))
    code_hash = hashlib.sha256(code.encode("utf-8")).hexdigest()
    tamper_status = False
    lock = getattr(fixer, "lock", None)
    if lock is not None and hasattr(lock, "is_valid"):
        try:
            tamper_status = not bool(lock.is_valid(code))
        except Exception:
            tamper_status = True
    return SystemState(
        timestamp=datetime.now(timezone.utc),
        score=int(getattr(fixer, "score", 0)),
        bug_count=int(getattr(fixer, "bug_count", 0)),
        tamper_status=tamper_status,
        backup_hash=backup_hash or getattr(fixer, "last_backup_hash", None),
        code_hash=code_hash,
    )
