const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const readline = require("readline");

function sha256(buffer) {
  return crypto.createHash("sha256").update(buffer).digest();
}

function normalizeProofNode(node) {
  if (typeof node === "string") return { hash: Buffer.from(node, "hex"), side: "right" };
  if (node && typeof node === "object") {
    const hex = node.hash || node.sibling || node.value;
    const side = String(node.side || node.position || node.direction || "right").toLowerCase();
    if (!hex) throw new Error("Proof node is missing hash");
    return { hash: Buffer.from(hex, "hex"), side };
  }
  throw new Error("Invalid proof node");
}

function fallbackVerify(msg) {
  let current = Buffer.from(msg.leaf, "hex");
  for (const rawNode of Array.isArray(msg.proof) ? msg.proof : []) {
    const { hash, side } = normalizeProofNode(rawNode);
    current = side === "left" ? sha256(Buffer.concat([hash, current])) : sha256(Buffer.concat([current, hash]));
  }
  return current.toString("hex") === String(msg.root).toLowerCase();
}

function loadExternalVerifier() {
  const candidates = [
    path.resolve(process.cwd(), "merkle.js"),
    path.resolve(__dirname, "..", "merkle.js"),
    path.resolve(__dirname, "merkle.js"),
  ];
  for (const file of candidates) {
    if (!fs.existsSync(file)) continue;
    try {
      const mod = require(file);
      const verifier = mod.verifyInclusionProof || mod.verifyMerkleProof || mod.verifyProof || mod.default;
      if (typeof verifier === "function") {
        return async (msg) => {
          const attempts = [
            () => verifier(msg),
            () => verifier(msg.leaf, msg.proof, msg.root),
            () => verifier(msg.leaf, msg.proof, msg.root, msg.index, msg.treeSize),
          ];
          let lastError = null;
          for (const run of attempts) {
            try {
              const value = await run();
              if (typeof value === "boolean") return { valid: value };
              if (value && typeof value.valid === "boolean") return value;
            } catch (err) {
              lastError = err;
            }
          }
          if (lastError) throw lastError;
          return { valid: fallbackVerify(msg) };
        };
      }
    } catch (_err) {}
  }
  return null;
}

const externalVerify = loadExternalVerifier();
const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });

rl.on("line", async (line) => {
  try {
    const msg = JSON.parse(line);
    const result = externalVerify ? await externalVerify(msg) : { valid: fallbackVerify(msg) };
    process.stdout.write(JSON.stringify({ valid: !!result.valid, error: result.error || null }) + "\n");
  } catch (err) {
    process.stdout.write(JSON.stringify({ valid: false, error: err.message }) + "\n");
  }
});
