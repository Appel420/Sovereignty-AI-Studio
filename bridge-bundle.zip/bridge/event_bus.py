from __future__ import annotations
import asyncio
from collections.abc import Awaitable, Callable
from typing import Any, Dict, List

EventCallback = Callable[[Dict[str, Any]], Awaitable[None] | None]

class EventBus:
    def __init__(self) -> None:
        self.queue: asyncio.Queue[tuple[str, Dict[str, Any]]] = asyncio.Queue()
        self.subscribers: Dict[str, List[EventCallback]] = {}
        self._task: asyncio.Task | None = None
        self._running = False

    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._running = True
        self._task = asyncio.create_task(self._dispatch_loop(), name="bridge-event-bus")

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def publish(self, event_type: str, payload: Dict[str, Any]) -> None:
        await self.queue.put((event_type, payload))

    def subscribe(self, event_type: str, callback: EventCallback) -> None:
        self.subscribers.setdefault(event_type, []).append(callback)

    async def _dispatch_loop(self) -> None:
        while self._running:
            event_type, payload = await self.queue.get()
            for cb in [*self.subscribers.get(event_type, []), *self.subscribers.get("*", [])]:
                task = cb(payload)
                if asyncio.iscoroutine(task):
                    asyncio.create_task(task)
            self.queue.task_done()

bus = EventBus()
