from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

class Event(BaseModel):
    type: str
    payload: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=utc_now)
    signature: Optional[str] = None

class SystemState(BaseModel):
    timestamp: datetime
    score: int
    bug_count: int
    tamper_status: bool
    backup_hash: Optional[str]
    code_hash: str

class VerificationRequest(BaseModel):
    leaf: str
    proof: List[Any] = Field(default_factory=list)
    root: str

class VerificationResult(BaseModel):
    valid: bool
    error: Optional[str] = None
