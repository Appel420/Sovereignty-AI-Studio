from __future__ import annotations
import asyncio
import json
import shutil
import time
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Deque
from fastapi import FastAPI, HTTPException
from .event_bus import bus
from .protocol import Event, VerificationRequest
from .state_adapter import build_state

ROOT = Path(__file__).resolve().parent
WORKER_PATH = ROOT / "merkle_worker.js"
worker_proc: asyncio.subprocess.Process | None = None
worker_lock = asyncio.Lock()
runtime_fixer: Any | None = None
recent_events: Deque[dict[str, Any]] = deque(maxlen=100)
last_state: dict[str, Any] | None = None
start_time = time.monotonic()
metrics: dict[str, Any] = {
    "events_total": 0,
    "verifications": 0,
    "verification_fail": 0,
    "tamper_events": 0,
    "worker_restarts": 0,
    "last_verify_ms": 0.0,
}

def _dump(model: Any) -> dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump(mode="json")
    return model.dict()

def register_self_fixer(fixer: Any, backup_hash: str | None = None) -> None:
    global runtime_fixer, last_state
    runtime_fixer = fixer
    last_state = _dump(build_state(fixer, backup_hash))

async def _start_worker() -> None:
    global worker_proc
    node_bin = shutil.which("node")
    if not node_bin:
        raise RuntimeError("Node.js is required to start merkle_worker.js")
    worker_proc = await asyncio.create_subprocess_exec(
        node_bin,
        str(WORKER_PATH),
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

async def _record_event(payload: dict[str, Any]) -> None:
    global last_state
    recent_events.append(payload)
    if payload.get("type") == "TAMPER_EVENT":
        metrics["tamper_events"] += 1
    if runtime_fixer is not None:
        backup_hash = payload.get("payload", {}).get("backup_hash")
        last_state = _dump(build_state(runtime_fixer, backup_hash))
    elif "payload" in payload and isinstance(payload["payload"], dict):
        state_hash = payload["payload"].get("state_hash")
        if state_hash:
            last_state = {
                "timestamp": payload.get("timestamp"),
                "score": int(payload["payload"].get("score", 0)),
                "bug_count": int(payload["payload"].get("bug_count", 0)),
                "tamper_status": payload.get("type") == "TAMPER_EVENT",
                "backup_hash": payload["payload"].get("backup_hash"),
                "code_hash": state_hash,
            }

async def verify_with_worker(payload: dict[str, Any]) -> dict[str, Any]:
    global worker_proc
    if worker_proc is None or worker_proc.returncode is not None:
        metrics["worker_restarts"] += 1
        await _start_worker()
    assert worker_proc is not None and worker_proc.stdin is not None and worker_proc.stdout is not None
    async with worker_lock:
        worker_proc.stdin.write((json.dumps(payload) + "\n").encode("utf-8"))
        await worker_proc.stdin.drain()
        line = await worker_proc.stdout.readline()
    if not line:
        stderr = b""
        if worker_proc.stderr is not None:
            try:
                stderr = await asyncio.wait_for(worker_proc.stderr.read(), timeout=0.2)
            except asyncio.TimeoutError:
                pass
        raise HTTPException(
            status_code=502,
            detail=f"Merkle worker exited unexpectedly: {stderr.decode('utf-8', 'ignore')}",
        )
    try:
        return json.loads(line.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=502, detail=f"Invalid worker response: {exc}") from exc

@asynccontextmanager
async def lifespan(app: FastAPI):
    bus.subscribe("*", _record_event)
    await bus.start()
    await _start_worker()
    try:
        yield
    finally:
        await bus.stop()
        if worker_proc is not None and worker_proc.returncode is None:
            worker_proc.terminate()
            await worker_proc.wait()

app = FastAPI(title="SelfFixer Bridge Gateway", lifespan=lifespan)

@app.post("/event")
async def ingest_event(event: Event):
    metrics["events_total"] += 1
    event_dict = _dump(event)
    await bus.publish(event.type, event_dict)
    return {"status": "queued", "event_type": event.type}

@app.post("/verify")
async def verify(req: VerificationRequest):
    metrics["verifications"] += 1
    started = time.perf_counter()
    result = await verify_with_worker(_dump(req))
    metrics["last_verify_ms"] = round((time.perf_counter() - started) * 1000, 3)
    if not result.get("valid", False):
        metrics["verification_fail"] += 1
    return result

@app.get("/metrics")
async def get_metrics():
    return {
        **metrics,
        "queue_depth": bus.queue.qsize(),
        "recent_events": len(recent_events),
        "uptime_s": round(time.monotonic() - start_time, 3),
    }

@app.get("/health")
async def health():
    return {
        "status": "ok",
        "worker_alive": worker_proc is not None and worker_proc.returncode is None,
        "queue_depth": bus.queue.qsize(),
    }

@app.get("/state")
async def get_state():
    return last_state or {}

@app.get("/events/recent")
async def get_recent_events():
    return list(recent_events)
