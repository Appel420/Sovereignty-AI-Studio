// src/server.js
// AMR v1 - binds to 127.0.0.1 only by default. Set AMR_HOST=0.0.0.0
// explicitly if you actually want LAN exposure; local-first is the default,
// not an opt-out.

const express = require('express');
const http = require('http');
const path = require('path');
const { WebSocketServer } = require('ws');

const db = require('./db');
const audit = require('./audit');

const companies = require('./routes/companies');
const providers = require('./routes/providers');
const models = require('./routes/models');
const apis = require('./routes/apis');
const evidence = require('./routes/evidence');
const dependencies = require('./routes/dependencies');
const risk = require('./routes/risk');
const timeline = require('./routes/timeline');
const entities = require('./routes/entities');

const HOST = process.env.AMR_HOST || '127.0.0.1';
const PORT = process.env.AMR_PORT || 9899;

const app = express();
app.use(express.json());

// Security headers - CSP restricts the terminal to same-origin script/style/
// connect only (fetch + WS to this server), blocks inline eval, and stops
// the browser from MIME-sniffing responses into something executable.
// MUST be registered before express.static, or static responses (including
// the terminal HTML itself) short-circuit the chain before headers are set.
app.use((req, res, next) => {
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; " +
    "connect-src 'self' ws: wss:; img-src 'self' data:; object-src 'none'; base-uri 'self'"
  );
  res.setHeader('X-Content-Type-Options', 'nosniff');
  next();
});

// Dashboard is a static file - no server-side rendering, no business logic
// in the frontend. It only calls the REST API and the WS feed defined below.
app.use(express.static(path.join(__dirname, '..', 'public')));

// express.json() throws synchronously on malformed JSON bodies - catch it
// here so a bad request body returns 400 instead of an unhandled exception.
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'invalid_json_body' });
  }
  next(err);
});

app.use('/api/companies', companies);
app.use('/api/providers', providers);
app.use('/api/models', models);
app.use('/api/apis', apis);
app.use('/api/evidence', evidence);
app.use('/api/dependencies', dependencies);
app.use('/api/risk', risk);
app.use('/api/timeline', timeline);
app.use('/api/entities', entities);

app.get('/api/audit/verify', (req, res) => {
  res.json(audit.verifyChain());
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'amr-v1', ts: new Date().toISOString() });
});

// Catch-all: SQLite FOREIGN KEY / UNIQUE constraint violations and any other
// synchronous throw inside a route handler land here instead of crashing
// the process. Express 4 catches sync throws in normal handlers automatically
// and routes them to this middleware as long as it's registered after routes.
app.use((err, req, res, next) => {
  console.error('[AMR] unhandled route error:', err.message);
  const isConstraint = /FOREIGN KEY|UNIQUE constraint|NOT NULL constraint/.test(err.message || '');
  res.status(isConstraint ? 400 : 500).json({
    error: isConstraint ? 'constraint_violation' : 'internal_error',
    detail: err.message
  });
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws/events' });

function broadcast(event) {
  const msg = JSON.stringify(event);
  wss.clients.forEach(c => { if (c.readyState === 1) c.send(msg); });
}

// Poor-man's live feed: poll audit_log for new rows and push them.
// Swap for a proper pub/sub if/when the write volume justifies it.
let lastSeenId = 0;
setInterval(() => {
  const rows = db.prepare('SELECT * FROM audit_log WHERE id > ? ORDER BY id ASC').all(lastSeenId);
  for (const row of rows) {
    lastSeenId = row.id;
    broadcast({ type: 'audit_event', ...row });
  }
}, 1000);

server.listen(PORT, HOST, () => {
  console.log(`[AMR] listening on http://${HOST}:${PORT}`);
  console.log(`[AMR] websocket live feed on ws://${HOST}:${PORT}/ws/events`);
});
