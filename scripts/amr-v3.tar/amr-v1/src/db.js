// src/db.js
// Local-only SQLite store. No network calls. File lives in ./data/amr.db
// Binds to disk, not to any remote host - satisfies local-first / air-gap posture.

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, 'amr.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS companies (
  company_id      TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  type            TEXT NOT NULL DEFAULT 'AI_PROVIDER',
  status          TEXT NOT NULL DEFAULT 'LISTED',
  website         TEXT,
  country         TEXT,
  founded         TEXT,
  ownership       TEXT,
  risk_rating     TEXT DEFAULT 'UNRATED',
  evidence_score  INTEGER DEFAULT 0,
  created_at      TEXT NOT NULL,
  updated_at      TEXT NOT NULL
);

-- Company vs Provider: a Company is a legal/ownership entity (OpenAI, Microsoft).
-- A Provider is who actually deploys and is operationally accountable for a
-- given model/API (OpenAI's own API vs. Microsoft's Azure AI deployment of
-- a licensed model). Two providers under different companies can point at
-- the same underlying model - that distinction is the whole point of
-- separating them, and is what lets "who is actually responsible" resolve
-- to something other than "the model's original creator" by default.
CREATE TABLE IF NOT EXISTS providers (
  provider_id TEXT PRIMARY KEY,
  company_id  TEXT NOT NULL REFERENCES companies(company_id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  type        TEXT NOT NULL DEFAULT 'DIRECT',   -- DIRECT | CLOUD_DEPLOYMENT | RESELLER | HOSTED
  status      TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS models (
  model_id            TEXT PRIMARY KEY,
  company_id          TEXT NOT NULL REFERENCES companies(company_id) ON DELETE CASCADE,
  provider_id         TEXT REFERENCES providers(provider_id) ON DELETE SET NULL,
  name                TEXT NOT NULL,
  category            TEXT NOT NULL DEFAULT 'FOUNDATION_MODEL',
  modalities          TEXT NOT NULL DEFAULT '[]',   -- JSON array
  status              TEXT NOT NULL DEFAULT 'ACTIVE',
  release_date        TEXT,
  api_available       INTEGER NOT NULL DEFAULT 0,   -- boolean 0/1
  cloud_dependencies  TEXT NOT NULL DEFAULT '[]',   -- JSON array
  risk_score          INTEGER DEFAULT 0,
  confidence          INTEGER DEFAULT 0,
  created_at          TEXT NOT NULL,
  updated_at          TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS apis (
  api_id      TEXT PRIMARY KEY,
  provider_id TEXT REFERENCES providers(provider_id) ON DELETE SET NULL,
  provider    TEXT NOT NULL,   -- kept as free-text label for backward compat / display
  model       TEXT,
  version     TEXT,
  endpoint    TEXT,
  status      TEXT NOT NULL DEFAULT 'ACTIVE',
  regions     TEXT NOT NULL DEFAULT '[]',   -- JSON array
  latency     TEXT NOT NULL DEFAULT '{}',   -- JSON object
  incidents   TEXT NOT NULL DEFAULT '[]',   -- JSON array
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dependencies (
  dependency_id TEXT PRIMARY KEY,
  source        TEXT NOT NULL,
  target        TEXT NOT NULL,
  relationship  TEXT NOT NULL DEFAULT 'USES',
  type          TEXT NOT NULL DEFAULT '[]',   -- JSON array
  confidence    INTEGER DEFAULT 0,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS evidence (
  evidence_id   TEXT PRIMARY KEY,
  entity_id     TEXT NOT NULL,
  source_type   TEXT NOT NULL DEFAULT 'OFFICIAL_DOCUMENT',
  source        TEXT,
  timestamp     TEXT NOT NULL,
  verification  TEXT NOT NULL DEFAULT 'UNVERIFIED',
  confidence    INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS audit_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  ts          TEXT NOT NULL,
  actor       TEXT NOT NULL DEFAULT 'system',
  action      TEXT NOT NULL,
  entity_type TEXT,
  entity_id   TEXT,
  payload     TEXT,
  prev_hash   TEXT,
  hash        TEXT
);
`);

module.exports = db;
