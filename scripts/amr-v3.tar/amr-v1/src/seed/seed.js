// src/seed/seed.js
// Seeds the company registry. Note: evidence_score starts at 0 for every
// row on purpose - "nothing gets displayed without evidence" (Phase 2).
// This seed only registers entities; it does NOT fabricate evidence records.
// Run `npm run seed`, then populate /api/evidence for each company before
// they should count as "verified" in any UI view.

const db = require('../db');
const audit = require('../audit');
const companies = require('./companies.json');
const providers = require('./providers.json');

const insertCompany = db.prepare(`
  INSERT OR IGNORE INTO companies
    (company_id, name, type, status, website, country, founded, ownership, risk_rating, evidence_score, created_at, updated_at)
  VALUES
    (@company_id, @name, @type, 'LISTED', NULL, NULL, NULL, NULL, @risk_rating, 0, @now, @now)
`);

const insertProvider = db.prepare(`
  INSERT OR IGNORE INTO providers
    (provider_id, company_id, name, type, status, created_at, updated_at)
  VALUES
    (@provider_id, @company_id, @name, @type, 'ACTIVE', @now, @now)
`);

const now = new Date().toISOString();
const tx = db.transaction((companyRows, providerRows) => {
  for (const c of companyRows) {
    insertCompany.run({ ...c, now });
    audit.record({
      actor: 'seed_script', action: 'company.seed',
      entity_type: 'company', entity_id: c.company_id, payload: c
    });
  }
  for (const p of providerRows) {
    insertProvider.run({ ...p, now });
    audit.record({
      actor: 'seed_script', action: 'provider.seed',
      entity_type: 'provider', entity_id: p.provider_id, payload: p
    });
  }
});

tx(companies, providers);
console.log(`[AMR seed] inserted/verified ${companies.length} companies and ${providers.length} providers.`);
console.log(`[AMR seed] evidence_score is 0 for all companies until /api/evidence rows are added.`);
console.log(`[AMR seed] note: providers/companies.json shows Azure AI (Microsoft) and Bedrock/Vertex`);
console.log(`[AMR seed] as separate providers from the model creators - accountability != authorship.`);
