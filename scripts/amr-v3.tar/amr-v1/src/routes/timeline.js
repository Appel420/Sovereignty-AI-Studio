const express = require('express');
const db = require('../db');

const router = express.Router();

// GET /api/timeline?entity_id=...   -> chronological history for one entity
// GET /api/timeline                  -> global feed, most recent first, capped
//
// Deliberately NOT a separate table. audit_log is already the append-only,
// hash-chained record of every write in the system - building a second
// "timeline_events" table would mean two things claiming to be the history
// of the same fact, which is the exact failure mode the hash chain exists
// to prevent. This route is a read-shaped view over audit_log, nothing more.
router.get('/', (req, res) => {
  const rows = req.query.entity_id
    ? db.prepare('SELECT * FROM audit_log WHERE entity_id = ? ORDER BY id ASC').all(req.query.entity_id)
    : db.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT 200').all();

  const events = rows.map(r => ({
    date: r.ts,
    action: r.action,
    entity_type: r.entity_type,
    entity_id: r.entity_id,
    actor: r.actor,
    hash: r.hash,
    previous_hash: r.prev_hash,
    payload: r.payload ? JSON.parse(r.payload) : null
  }));

  res.json(req.query.entity_id
    ? { entity_id: req.query.entity_id, events }
    : { events }
  );
});

module.exports = router;
