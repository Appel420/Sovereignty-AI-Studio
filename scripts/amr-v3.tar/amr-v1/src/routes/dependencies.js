const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const audit = require('../audit');

const router = express.Router();

router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM dependencies').all();
  res.json(rows.map(r => ({ ...r, type: JSON.parse(r.type || '[]') })));
});

router.post('/', (req, res) => {
  const b = req.body;
  if (!b.source || !b.target) {
    return res.status(400).json({ error: 'source and target are required' });
  }
  const dependency_id = b.dependency_id || crypto.randomUUID();
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO dependencies (dependency_id, source, target, relationship, type, confidence, created_at, updated_at)
    VALUES (@dependency_id, @source, @target, @relationship, @type, @confidence, @created_at, @updated_at)
  `).run({
    dependency_id,
    source: b.source,
    target: b.target,
    relationship: b.relationship || 'USES',
    type: JSON.stringify(b.type || []),
    confidence: b.confidence || 0,
    created_at: now,
    updated_at: now
  });
  audit.record({ action: 'dependency.create', entity_type: 'dependency', entity_id: dependency_id, payload: b });
  res.status(201).json({ dependency_id });
});

// GET /api/dependencies/concentration/:companyId
// Naive concentration-risk metric: how many distinct dependency targets
// a company's models rely on, and how skewed the reliance is toward one target.
router.get('/concentration/:companyId', (req, res) => {
  const rows = db.prepare(`
    SELECT target, COUNT(*) as cnt FROM dependencies
    WHERE source = ? GROUP BY target ORDER BY cnt DESC
  `).all(req.params.companyId);

  const total = rows.reduce((s, r) => s + r.cnt, 0);
  const top = rows[0] ? rows[0].cnt / total : 0;
  const concentration_risk = Math.round(top * 100);

  res.json({ company_id: req.params.companyId, targets: rows, concentration_risk });
});

module.exports = router;
