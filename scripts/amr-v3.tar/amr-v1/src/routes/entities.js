const express = require('express');
const db = require('../db');

const router = express.Router();

// GET /api/entities
// Single discovery feed for the terminal UI. Purely a read-shaped view over
// existing tables (companies, providers, models, apis) - no new storage,
// no denormalized copy that could drift from the source rows. Every item
// carries its real status field verbatim; the terminal is responsible for
// deciding how to LABEL that status (e.g. "DENIED"), not this endpoint.
router.get('/', (req, res) => {
  const companies = db.prepare('SELECT * FROM companies').all().map(c => ({
    entity_type: 'company',
    id: c.company_id,
    name: c.name,
    status: c.status,
    risk_rating: c.risk_rating,
    evidence_score: c.evidence_score,
    parent_id: null
  }));

  const providers = db.prepare('SELECT * FROM providers').all().map(p => ({
    entity_type: 'provider',
    id: p.provider_id,
    name: p.name,
    status: p.status,
    provider_type: p.type,
    parent_id: p.company_id
  }));

  const models = db.prepare('SELECT * FROM models').all().map(m => ({
    entity_type: 'model',
    id: m.model_id,
    name: m.name,
    status: m.status,
    category: m.category,
    modalities: JSON.parse(m.modalities || '[]'),
    parent_id: m.provider_id || m.company_id,
    company_id: m.company_id,
    provider_id: m.provider_id
  }));

  const apis = db.prepare('SELECT * FROM apis').all().map(a => ({
    entity_type: 'api',
    id: a.api_id,
    name: a.model || a.provider,
    status: a.status,
    version: a.version,
    parent_id: a.provider_id
  }));

  res.json({
    generated_at: new Date().toISOString(),
    source: 'local_sqlite_registry',
    counts: {
      companies: companies.length,
      providers: providers.length,
      models: models.length,
      apis: apis.length
    },
    entities: [...companies, ...providers, ...models, ...apis]
  });
});

module.exports = router;
