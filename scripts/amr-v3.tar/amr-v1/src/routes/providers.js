const express = require('express');
const db = require('../db');
const audit = require('../audit');
const { validatePartial } = require('../validate');

const router = express.Router();

router.get('/', (req, res) => {
  const rows = req.query.company_id
    ? db.prepare('SELECT * FROM providers WHERE company_id = ?').all(req.query.company_id)
    : db.prepare('SELECT * FROM providers ORDER BY updated_at DESC').all();
  res.json(rows);
});

router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM providers WHERE provider_id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'not_found' });
  res.json(row);
});

router.post('/', validatePartial('provider'), (req, res) => {
  const b = req.body;
  if (!b.provider_id || !b.company_id || !b.name) {
    return res.status(400).json({ error: 'provider_id, company_id, name are required' });
  }
  const owner = db.prepare('SELECT company_id FROM companies WHERE company_id = ?').get(b.company_id);
  if (!owner) return res.status(400).json({ error: 'company_id does not reference a registered company' });

  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO providers (provider_id, company_id, name, type, status, created_at, updated_at)
    VALUES (@provider_id, @company_id, @name, @type, @status, @created_at, @updated_at)
  `).run({
    provider_id: b.provider_id,
    company_id: b.company_id,
    name: b.name,
    type: b.type || 'DIRECT',
    status: b.status || 'ACTIVE',
    created_at: now,
    updated_at: now
  });
  audit.record({ action: 'provider.create', entity_type: 'provider', entity_id: b.provider_id, payload: b });
  res.status(201).json({ provider_id: b.provider_id });
});

router.patch('/:id', validatePartial('provider'), (req, res) => {
  const existing = db.prepare('SELECT * FROM providers WHERE provider_id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'not_found' });
  const merged = { ...existing, ...req.body, updated_at: new Date().toISOString() };
  db.prepare(`
    UPDATE providers SET company_id=@company_id, name=@name, type=@type, status=@status, updated_at=@updated_at
    WHERE provider_id=@provider_id
  `).run(merged);
  audit.record({ action: 'provider.update', entity_type: 'provider', entity_id: req.params.id, payload: req.body });
  res.json({ ok: true });
});

// GET /api/providers/:id/tree - everything a provider is accountable for.
// This is the "who is actually responsible" query the whole split exists for.
router.get('/:id/tree', (req, res) => {
  const provider = db.prepare('SELECT * FROM providers WHERE provider_id = ?').get(req.params.id);
  if (!provider) return res.status(404).json({ error: 'not_found' });

  const models = db.prepare('SELECT model_id, name, status FROM models WHERE provider_id = ?').all(req.params.id);
  const apis = db.prepare('SELECT api_id, model, version, status FROM apis WHERE provider_id = ?').all(req.params.id);

  res.json({ provider, models, apis });
});

module.exports = router;
