const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const audit = require('../audit');
const { validatePartial } = require('../validate');

const router = express.Router();

router.get('/', (req, res) => {
  const rows = req.query.entity_id
    ? db.prepare('SELECT * FROM evidence WHERE entity_id = ? ORDER BY timestamp DESC').all(req.query.entity_id)
    : db.prepare('SELECT * FROM evidence ORDER BY timestamp DESC').all();
  res.json(rows);
});

// Recomputes companies.evidence_score as the mean confidence of CONFIRMED
// evidence rows for that entity_id. Only CONFIRMED counts toward the score -
// an UNVERIFIED or DISPUTED piece of evidence existing is not the same as
// it having raised confidence in the entity. No-op if entity_id isn't a
// registered company (e.g. evidence attached to a model/api/provider row) -
// evidence_score is a companies-table field only, by current schema.
function recomputeEvidenceScore(entity_id) {
  const company = db.prepare('SELECT company_id FROM companies WHERE company_id = ?').get(entity_id);
  if (!company) return null;

  const rows = db.prepare(
    `SELECT confidence FROM evidence WHERE entity_id = ? AND verification = 'CONFIRMED'`
  ).all(entity_id);

  const score = rows.length
    ? Math.round(rows.reduce((s, r) => s + r.confidence, 0) / rows.length)
    : 0;

  db.prepare('UPDATE companies SET evidence_score = ?, updated_at = ? WHERE company_id = ?')
    .run(score, new Date().toISOString(), entity_id);

  return score;
}

// Nothing is displayed without evidence - this is the enforcement point.
// A company/model with zero rows here should be filtered out by the UI layer.
router.post('/', validatePartial('evidence'), (req, res) => {
  const b = req.body;
  if (!b.entity_id || !b.source) {
    return res.status(400).json({ error: 'entity_id and source are required' });
  }
  const evidence_id = b.evidence_id || crypto.randomUUID();
  const timestamp = b.timestamp || new Date().toISOString();

  db.prepare(`
    INSERT INTO evidence (evidence_id, entity_id, source_type, source, timestamp, verification, confidence)
    VALUES (@evidence_id, @entity_id, @source_type, @source, @timestamp, @verification, @confidence)
  `).run({
    evidence_id,
    entity_id: b.entity_id,
    source_type: b.source_type || 'OFFICIAL_DOCUMENT',
    source: b.source,
    timestamp,
    verification: b.verification || 'UNVERIFIED',
    confidence: b.confidence || 0
  });

  audit.record({ action: 'evidence.create', entity_type: 'evidence', entity_id: evidence_id, payload: b });

  const newScore = recomputeEvidenceScore(b.entity_id);
  if (newScore !== null) {
    audit.record({
      action: 'company.evidence_score_recomputed',
      entity_type: 'company',
      entity_id: b.entity_id,
      payload: { evidence_score: newScore, trigger_evidence_id: evidence_id }
    });
  }

  res.status(201).json({ evidence_id, evidence_score: newScore });
});

module.exports = router;
