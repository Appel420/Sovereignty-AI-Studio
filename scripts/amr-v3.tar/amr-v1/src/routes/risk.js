const express = require('express');
const db = require('../db');

const router = express.Router();

// GET /api/risk/:companyId
// Aggregates the six risk metrics described in the spec. Availability and
// security risk are placeholders here (0) until incident/API-uptime feeds
// are wired in - they are returned explicitly as 0/unrated rather than
// silently omitted, so the UI can show "no data" instead of a fake number.
router.get('/:companyId', (req, res) => {
  const company = db.prepare('SELECT * FROM companies WHERE company_id = ?').get(req.params.companyId);
  if (!company) return res.status(404).json({ error: 'not_found' });

  const depRows = db.prepare('SELECT target, COUNT(*) as cnt FROM dependencies WHERE source = ? GROUP BY target')
    .all(req.params.companyId);
  const totalDeps = depRows.reduce((s, r) => s + r.cnt, 0);
  const concentration_risk = totalDeps ? Math.round((depRows[0].cnt / totalDeps) * 100) : 0;
  const dependency_risk = Math.min(100, totalDeps * 10);

  const evidenceRows = db.prepare('SELECT confidence FROM evidence WHERE entity_id = ?').all(req.params.companyId);
  const evidence_confidence = evidenceRows.length
    ? Math.round(evidenceRows.reduce((s, r) => s + r.confidence, 0) / evidenceRows.length)
    : 0;

  res.json({
    company_id: req.params.companyId,
    dependency_risk,
    availability_risk: null,   // requires uptime/incident feed - not fabricated
    security_risk: null,       // requires CVE/incident feed - not fabricated
    concentration_risk,
    evidence_confidence,
    accountability_clarity: company.ownership ? 80 : 20
  });
});

module.exports = router;
