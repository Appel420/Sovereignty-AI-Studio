const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const audit = require('../audit');
const { validatePartial } = require('../validate');

const router = express.Router();

// Dependencies and evidence for an API are NOT stored as JSON arrays on the
// row - they're pulled live from the dependencies/evidence tables keyed on
// api_id. Storing them twice (once as JSON blob, once as rows) is exactly
// the kind of drift that breaks provenance - see the audit-chain bug from
// the last milestone. One source of truth per fact.
function attach(row) {
  const dependencies = db.prepare('SELECT * FROM dependencies WHERE source = ?').all(row.api_id);
  const evidence = db.prepare('SELECT * FROM evidence WHERE entity_id = ?').all(row.api_id);
  return {
    ...row,
    regions: JSON.parse(row.regions || '[]'),
    latency: JSON.parse(row.latency || '{}'),
    incidents: JSON.parse(row.incidents || '[]'),
    dependencies,
    evidence
  };
}

router.get('/', (req, res) => {
  const rows = req.query.provider_id
    ? db.prepare('SELECT * FROM apis WHERE provider_id = ?').all(req.query.provider_id)
    : db.prepare('SELECT * FROM apis ORDER BY updated_at DESC').all();
  res.json(rows.map(attach));
});

router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM apis WHERE api_id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'not_found' });
  res.json(attach(row));
});

router.post('/', validatePartial('api'), (req, res) => {
  const b = req.body;
  if (!b.provider) {
    return res.status(400).json({ error: 'provider (display label) is required' });
  }
  if (b.provider_id) {
    const p = db.prepare('SELECT provider_id FROM providers WHERE provider_id = ?').get(b.provider_id);
    if (!p) return res.status(400).json({ error: 'provider_id does not reference a registered provider' });
  }
  const api_id = b.api_id || crypto.randomUUID();
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO apis (api_id, provider_id, provider, model, version, endpoint, status, regions, latency, incidents, created_at, updated_at)
    VALUES (@api_id, @provider_id, @provider, @model, @version, @endpoint, @status, @regions, @latency, @incidents, @created_at, @updated_at)
  `).run({
    api_id,
    provider_id: b.provider_id || null,
    provider: b.provider,
    model: b.model || null,
    version: b.version || null,
    endpoint: b.endpoint || null,
    status: b.status || 'ACTIVE',
    regions: JSON.stringify(b.regions || []),
    latency: JSON.stringify(b.latency || {}),
    incidents: JSON.stringify(b.incidents || []),
    created_at: now,
    updated_at: now
  });
  audit.record({ action: 'api.create', entity_type: 'api', entity_id: api_id, payload: b });
  res.status(201).json({ api_id });
});

router.patch('/:id', validatePartial('api'), (req, res) => {
  const existing = db.prepare('SELECT * FROM apis WHERE api_id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'not_found' });

  const b = req.body;
  const merged = {
    ...existing,
    ...b,
    regions: JSON.stringify(b.regions ?? JSON.parse(existing.regions || '[]')),
    latency: JSON.stringify(b.latency ?? JSON.parse(existing.latency || '{}')),
    incidents: JSON.stringify(b.incidents ?? JSON.parse(existing.incidents || '[]')),
    updated_at: new Date().toISOString()
  };
  db.prepare(`
    UPDATE apis SET provider_id=@provider_id, provider=@provider, model=@model, version=@version,
      endpoint=@endpoint, status=@status, regions=@regions, latency=@latency, incidents=@incidents,
      updated_at=@updated_at
    WHERE api_id=@api_id
  `).run({ ...merged, api_id: req.params.id });

  audit.record({ action: 'api.update', entity_type: 'api', entity_id: req.params.id, payload: b });
  res.json({ ok: true });
});

router.delete('/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM apis WHERE api_id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'not_found' });

  db.prepare('DELETE FROM apis WHERE api_id = ?').run(req.params.id);
  // Deletion is itself an audited event - the row is gone but the fact that
  // it existed and was removed (by whom, when) stays in the hash chain.
  audit.record({ action: 'api.delete', entity_type: 'api', entity_id: req.params.id, payload: existing });
  res.json({ ok: true });
});

module.exports = router;
