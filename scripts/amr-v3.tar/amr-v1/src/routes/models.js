const express = require('express');
const db = require('../db');
const audit = require('../audit');
const { validatePartial } = require('../validate');

const router = express.Router();

function rowOut(row) {
  return {
    ...row,
    modalities: JSON.parse(row.modalities || '[]'),
    cloud_dependencies: JSON.parse(row.cloud_dependencies || '[]'),
    api_available: !!row.api_available
  };
}

router.get('/', (req, res) => {
  const q = req.query.company_id
    ? db.prepare('SELECT * FROM models WHERE company_id = ?').all(req.query.company_id)
    : db.prepare('SELECT * FROM models ORDER BY updated_at DESC').all();
  res.json(q.map(rowOut));
});

router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM models WHERE model_id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'not_found' });
  res.json(rowOut(row));
});

router.post('/', validatePartial('model'), (req, res) => {
  const b = req.body;
  if (!b.model_id || !b.company_id || !b.name) {
    return res.status(400).json({ error: 'model_id, company_id, name are required' });
  }
  if (b.provider_id) {
    const p = db.prepare('SELECT provider_id FROM providers WHERE provider_id = ?').get(b.provider_id);
    if (!p) return res.status(400).json({ error: 'provider_id does not reference a registered provider' });
  }
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO models (model_id, company_id, provider_id, name, category, modalities, status, release_date, api_available, cloud_dependencies, risk_score, confidence, created_at, updated_at)
    VALUES (@model_id, @company_id, @provider_id, @name, @category, @modalities, @status, @release_date, @api_available, @cloud_dependencies, @risk_score, @confidence, @created_at, @updated_at)
  `).run({
    model_id: b.model_id,
    company_id: b.company_id,
    provider_id: b.provider_id || null,
    name: b.name,
    category: b.category || 'FOUNDATION_MODEL',
    modalities: JSON.stringify(b.modalities || []),
    status: b.status || 'ACTIVE',
    release_date: b.release_date || null,
    api_available: b.api_available ? 1 : 0,
    cloud_dependencies: JSON.stringify(b.cloud_dependencies || []),
    risk_score: b.risk_score || 0,
    confidence: b.confidence || 0,
    created_at: now,
    updated_at: now
  });
  audit.record({ action: 'model.create', entity_type: 'model', entity_id: b.model_id, payload: b });
  res.status(201).json({ model_id: b.model_id });
});

module.exports = router;
