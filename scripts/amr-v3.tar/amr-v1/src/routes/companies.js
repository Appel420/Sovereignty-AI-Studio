const express = require('express');
const db = require('../db');
const audit = require('../audit');
const { validatePartial } = require('../validate');

const router = express.Router();

router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM companies ORDER BY evidence_score DESC').all();
  res.json(rows);
});

router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM companies WHERE company_id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'not_found' });
  res.json(row);
});

router.post('/', validatePartial('company'), (req, res) => {
  const b = req.body;
  if (!b.company_id || !b.name) {
    return res.status(400).json({ error: 'company_id and name are required' });
  }
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO companies (company_id, name, type, status, website, country, founded, ownership, risk_rating, evidence_score, created_at, updated_at)
    VALUES (@company_id, @name, @type, @status, @website, @country, @founded, @ownership, @risk_rating, @evidence_score, @created_at, @updated_at)
  `).run({
    company_id: b.company_id,
    name: b.name,
    type: b.type || 'AI_PROVIDER',
    status: b.status || 'LISTED',
    website: b.website || null,
    country: b.country || null,
    founded: b.founded || null,
    ownership: b.ownership || null,
    risk_rating: b.risk_rating || 'UNRATED',
    evidence_score: b.evidence_score || 0,
    created_at: now,
    updated_at: now
  });
  audit.record({ action: 'company.create', entity_type: 'company', entity_id: b.company_id, payload: b });
  res.status(201).json({ company_id: b.company_id });
});

router.patch('/:id', validatePartial('company'), (req, res) => {
  const existing = db.prepare('SELECT * FROM companies WHERE company_id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'not_found' });

  const merged = { ...existing, ...req.body, updated_at: new Date().toISOString() };
  db.prepare(`
    UPDATE companies SET name=@name, type=@type, status=@status, website=@website,
      country=@country, founded=@founded, ownership=@ownership, risk_rating=@risk_rating,
      evidence_score=@evidence_score, updated_at=@updated_at
    WHERE company_id=@company_id
  `).run(merged);

  audit.record({ action: 'company.update', entity_type: 'company', entity_id: req.params.id, payload: req.body });
  res.json({ ok: true });
});

module.exports = router;
