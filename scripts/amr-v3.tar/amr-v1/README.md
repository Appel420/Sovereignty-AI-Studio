# AMR v1 — AI Market Registry Core

Local-first registry of AI companies, models, APIs, and dependencies, with an
evidence ledger and a hash-chained audit log. This is Phase 1–4 from the spec
(schema, evidence, dependency/risk, and the data layer under the terminal UI).
The dark terminal UI is a separate frontend layer to build on top of this API.

## Why it's built this way

- **SQLite, single file, localhost-bound by default.** No cloud dependency
  to run the registry itself. `AMR_HOST=0.0.0.0` is opt-in, not default.
- **Evidence-gated by design.** `evidence_score` starts at 0 on every seeded
  company. Nothing should render as "verified" in a UI until real evidence
  rows exist for that entity — the seed script does not fabricate evidence.
- **Audit log is hash-chained**, not just append-only. `/api/audit/verify`
  walks the whole chain and reports the first broken link, if any.
- **Risk fields that require a data feed you don't have yet return `null`,
  not a fabricated number** (see `availability_risk` / `security_risk` in
  `/api/risk/:companyId`). Silent zeroes would be worse than admitting
  there's no data.

## Setup

```bash
cd amr-v1
npm install
npm run seed     # loads the initial company list, evidence_score=0
npm start         # http://127.0.0.1:9899
```

## Company vs. Provider

A **Company** is a legal/ownership entity (OpenAI, Microsoft). A **Provider**
is who is operationally accountable for a specific deployment (OpenAI's own
API vs. Microsoft's Azure AI hosting a licensed OpenAI model). Two providers
under different companies can point at the same underlying model — that's
the point. `GET /api/providers/:id/tree` answers "who is actually
responsible for this" instead of defaulting to "whoever built the model."

## Endpoints

| Method | Path                                   | Purpose                          |
|--------|-----------------------------------------|-----------------------------------|
| GET    | /api/companies                          | list all companies                |
| GET    | /api/companies/:id                      | one company                       |
| POST   | /api/companies                          | register a company                |
| PATCH  | /api/companies/:id                      | update a company                  |
| GET    | /api/providers?company_id=...           | list providers (optionally filtered) |
| GET    | /api/providers/:id                      | one provider                      |
| GET    | /api/providers/:id/tree                 | provider + everything it's accountable for |
| POST   | /api/providers                          | register a provider               |
| PATCH  | /api/providers/:id                      | update a provider                 |
| GET    | /api/models?company_id=...              | list models (optionally filtered) |
| POST   | /api/models                             | register a model                  |
| GET    | /api/apis?provider_id=...               | list APIs (optionally filtered)   |
| GET    | /api/apis/:id                           | one API + derived dependencies/evidence |
| POST   | /api/apis                               | register an API                   |
| PATCH  | /api/apis/:id                           | update an API                     |
| DELETE | /api/apis/:id                           | delete an API (audited, not silent) |
| GET    | /api/evidence?entity_id=...             | list evidence for an entity       |
| POST   | /api/evidence                           | attach evidence; auto-recomputes company evidence_score |
| GET    | /api/dependencies                       | list dependency edges             |
| POST   | /api/dependencies                       | register a dependency edge        |
| GET    | /api/dependencies/concentration/:id     | concentration-risk for a company  |
| GET    | /api/risk/:companyId                    | aggregated risk metrics           |
| GET    | /api/timeline?entity_id=...             | chronological history for one entity |
| GET    | /api/timeline                           | global feed, most recent 200      |
| GET    | /api/audit/verify                       | verify the audit hash chain       |
| GET    | /api/health                             | liveness check                    |
| WS     | /ws/events                              | live feed of audit_log writes     |

## evidence_score is now automatic

`POST /api/evidence` recomputes the target company's `evidence_score` as the
mean confidence of its `CONFIRMED` evidence rows. `UNVERIFIED` / `DISPUTED`
evidence existing does not raise the score — those are for the record, not
for credibility. The recompute itself is a separate audited event
(`company.evidence_score_recomputed`), so the timeline shows *why* a score
changed, not just that it did.

## Schema validation

`src/schemas/*.schema.json` are wired in via `src/validate.js` (ajv). POSTs
and PATCHes are checked against types/enums for any field present — e.g.
`risk_rating: "super-high"` is rejected with a 400 and the specific field
that failed, rather than silently coercing or hitting a raw SQLite error.
ID/required-field presence is still checked manually per route, since the
stored-row schemas (which require IDs and timestamps) are stricter than
what a client should have to send in a request body.

## Error handling

A catch-all error handler sits after all routes: malformed JSON bodies
return 400 instead of crashing, and SQLite constraint violations (bad
foreign keys, UNIQUE conflicts) return 400 with the SQLite message rather
than a raw 500 stack trace.

## Sovereignty AI Market Terminal (public/terminal.html)

A single self-contained HTML file (no React, no build step, no external
scripts) that turns the API above into a Bloomberg/NASDAQ-style terminal.
Served by the same Express app — `http://127.0.0.1:9899/terminal.html`.

What it actually does, verified end-to-end (not just written):
- **Local-first, graceful offline**: tries `/api/entities` first; if that
  fails, offers a file picker to load a local `verified_entities.json`
  instead. A strict-ish validator rejects malformed files (checked directly:
  missing required fields → rejected with specific field names; non-array
  payload → rejected) rather than silently rendering garbage as trustworthy.
- **Never claims LIVE unless it's true**: the FEED pill only says "LIVE"
  after the WebSocket's `onopen` actually fires; disconnected state says so
  and shows a retry countdown.
- **Denied entities stay visible.** A user-loaded policy file
  (`providers.allow` / `providers.deny`, client-side only, saved to
  `localStorage` — never sent to any server) relabels matching rows as
  `DENIED (policy)` / `ACCESS CONTROLLED`. It never removes a row. No
  provider or model is preferred or blocked by default — the shipped policy
  template is `"allow": ["*"], "deny": []`.
- **XSS-checked, not just "should be fine"**: every rendered field goes
  through `escapeHtml()`. Verified directly — posted a company named
  `<img src=x onerror=alert(1)>` through the real API, confirmed the raw
  tag comes back unescaped from `/api/entities` (correct — escaping isn't
  the API's job), then confirmed `escapeHtml()` neutralizes it to inert text
  before render.
- **CSP header actually applies** — this required a real fix: the header
  middleware was originally registered *after* `express.static`, so static
  responses (including the terminal itself) shipped with no CSP at all.
  Moved it before `express.static`; verified with `curl -D -` that the
  header is now present on the terminal's own response.
- Risk Radar, Dependency, Audit Ledger, and Evidence Trail tabs all call the
  real endpoints above (`/api/risk/:id`, `/api/dependencies/concentration/:id`,
  `/api/timeline`, `/api/evidence`) — nothing in those views is mocked data.

**What this artifact does *not* do, on purpose:** it does not make any
outbound internet calls to third-party sites. A single static HTML file
can't do that safely (CORS blocks arbitrary cross-origin fetches from a
page, and faking it around that would mean a hidden server-side proxy —
which breaks the air-gapped/local-first premise silently). If you want an
explicit "pull latest" action, that needs its own opt-in backend endpoint
you trigger deliberately — not something baked into the terminal's normal
load path.


1. Availability/security risk feeds (currently `null` — see above)
2. AI-100 index computation (Phase 3) — needs an adoption/usage data source
   before it can be anything but guesswork; flag this before building it
3. The dark terminal frontend (Phase 5) consuming this API + the WebSocket feed
4. Role-based access on write endpoints (currently open — fine for local-only
   single-user use, not fine once this is multi-user or network-exposed)
5. `evidence_score` recompute currently only applies to companies (the only
   table with that field) — models/apis/providers can carry evidence rows
   but have no equivalent score field yet to recompute into
