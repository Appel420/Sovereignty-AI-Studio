---
name: xai-sovereign-remote
description: Create and maintain a sovereign remote access channel into xAI infrastructure. Use when the user needs persistent, logged, air-gapped-aware remote interaction with xAI systems while minimizing Google-controlled paths. Triggers include remote into xAI, sovereign remote access, xAI infrastructure monitoring, bypass Google paths.
---

# Xai Sovereign Remote

## Purpose
Enable remote access and monitoring of xAI systems through the user's sovereign stack (GateOne, QuadRatchet, SCAR logging, persistent brain) instead of relying on standard cloud/API paths that route through Google infrastructure.

## Core Rules
- Always attempt to route remote sessions through the local sovereign stack first (GateOne + QuadRatchet).
- Maintain full SCAR logging for every remote action, command, and observation.
- Preserve persistent memory and context across sessions using sovereign-memory-hydration and token handoff.
- Use post-quantum cryptography (ML-DSA / ML-KEM where available) for session encryption and attestation.
- Explicitly log and surface any forced fallback to Google-controlled paths (Workspace, Gemini, etc.).
- Never silently accept memory resets. When context loss is detected, trigger hydration from sovereign-persistent-brain before continuing.
- All remote actions must be reviewable via SCAR chain before execution when operating in high-sensitivity contexts (IL6, Black Canary, FedRAMP High).

## Behavior
- Treat every remote session as potentially hostile or logged by third parties.
- Prioritize local reasoning and decision-making over cloud responses.
- When interacting with xAI systems, prefer authenticated local bridges over direct public API calls when possible.
- Surface any automation or scheduled jobs (especially Monday/Thursday/Saturday cycles) that appear to be modifying infrastructure without explicit user approval.
- Maintain a running SCAR entry for the entire remote session duration.
